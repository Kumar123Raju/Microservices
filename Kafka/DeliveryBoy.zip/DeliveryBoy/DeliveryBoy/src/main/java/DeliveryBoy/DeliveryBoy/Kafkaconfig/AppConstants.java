package DeliveryBoy.DeliveryBoy.Kafkaconfig;

public class AppConstants {
    public static final String LOCATION_TOPIC_NAME= "first-kraft-topic";
}
