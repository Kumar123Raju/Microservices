    package DeliveryBoy.DeliveryBoy.Service;

    import org.slf4j.LoggerFactory;
    import org.springframework.beans.factory.annotation.Autowired;
    import org.springframework.kafka.core.KafkaTemplate;
    import org.springframework.stereotype.Service;

//    import org.slf4j.Logger;


    import static DeliveryBoy.DeliveryBoy.Kafkaconfig.AppConstants.LOCATION_TOPIC_NAME;

    @Service
    public class KafkaService {

        @Autowired
        private KafkaTemplate<String,String> kafkaTemplate;

//        private Logger logger = LoggerFactory.getLogger(KafkaService.class);


        public boolean updateLocation(String location){
            this.kafkaTemplate.send(LOCATION_TOPIC_NAME,location);
            System.out.println("Location produced");
//            this.logger.info("Location Produced");
            return true;

        }

    }
