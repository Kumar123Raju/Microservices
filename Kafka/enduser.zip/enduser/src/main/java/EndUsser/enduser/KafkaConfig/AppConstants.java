package EndUsser.enduser.KafkaConfig;


public class AppConstants {
    public  static final String LOCATION_UPDATE_NAME="first-kraft-topic";
    public static final String GROUP_ID="group-1";
}
