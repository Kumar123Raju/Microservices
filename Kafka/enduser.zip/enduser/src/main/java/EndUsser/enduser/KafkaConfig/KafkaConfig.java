package EndUsser.enduser.KafkaConfig;


import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.KafkaListener;

import static EndUsser.enduser.KafkaConfig.AppConstants.GROUP_ID;
import static EndUsser.enduser.KafkaConfig.AppConstants.LOCATION_UPDATE_NAME;

@Configuration
public class KafkaConfig {

    @KafkaListener(topics=LOCATION_UPDATE_NAME,groupId = GROUP_ID)
    public void updatedLocation(String value){

        System.out.println(value);

    }

}
